<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-7">
        <div class="panel panel-primary">
            <div class="panel-heading">
                    <h3 style="text-align:center;">Hasil Tes IST</h3>
            </div>
            <div class="panel-body">
                <div class="container">
                    <div class="col-sm-6">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Nama Tes</th>
                                    <th>Skor Akhir</th>
                                    <th>Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for($i=0; $i < 9; $i++): ?>
                                <tr>
                                    <td><?php echo e($namas[$i]); ?></td>
                                    <td><?php echo e($hasils[$i]->hasil); ?></td>
                                    <td><?php echo e($hasils[$i]->keterangan); ?></td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-5">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 style="text-align:center;">Rekomendasi Jurusan</h3>
            </div>
            <div class = "panel-body">
                <div class="container">
                    <div class="col-sm-4">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Hasil Rekomendasi</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $rekoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($rek['nama']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>