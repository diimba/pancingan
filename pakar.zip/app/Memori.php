<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Memori extends Model
{
    protected $table = 'memori'; 
    public $timestamps = false;
}
