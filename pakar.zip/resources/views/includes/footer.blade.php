<div class="footer">
    <div id="copyright text-right">© Copyright Dimas Eko Wicaksono</div>
</div>